let mx = 0;
let my = 0;
let px = 0;
let py = 0;
let fr = 0;
let eSize = 3;
let eLoc = 10;

function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(250);
let fr = sqrt(75);
	frameRate(fr);
	print(fr);
	let mx = mouseX;
	let my = mouseY;
	let px = pmouseX;
	let py = pmouseY;
	colorMode(RGB,194, 144, 50, 1);
	strokeWeight(3);
	stroke(200, 50, 75, 0.75);
	line(mx, my, px, py); 
  fill(88, 153, 232);
  ellipse(eLoc, eLoc, eSize, eSize);
  ellipse(eLoc * 2, eLoc * 2, pow(eSize, 2), pow(eSize, 2));
  ellipse(eLoc * 4, eLoc * 4, pow(eSize, 3), pow(eSize, 3));
  ellipse(eLoc * 8, eLoc * 8, pow(eSize, 4), pow(eSize, 4));

  let Size = 7;
  let x1 = mouseX;
  let y1 = 80;
  let x2 = sqrt(x1);
  let y2 = 20;
    fill(66, 65, 13);
  line(0, y1, width, y1);
  ellipse(x1, y1, Size, Size);

  
  
  
  
  
  
  
  
  
  
  
  
}