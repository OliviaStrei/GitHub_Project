function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(20);
  fill(198, 138, 255);
  arc(200, 530, 650, 450, 90, TWO_PI);
  fill(255, 249, 184);
  rect(180, 200, 50, 80);
  fill(250, 94, 32, 178);
  triangle(196, 280, 206, 300, 216, 280);
  fill(255, 154, 150);
  triangle(173, 205, 205, 150, 236, 205);
  fill(138, 224, 255);
  noStroke();
  quad(190, 236, 205, 216, 219, 236, 205, 256);
  fill(255, 207, 153);
  triangle(180, 280, 170, 320, 200, 280);
  triangle(210, 280, 240, 320, 230, 280);
  fill(251, 255, 135);
  ellipse(326, 46, 70, 70);
  fill(255);
  ellipse(30, 46, 5, 5);
  ellipse(180, 126, 5, 5);
  ellipse(40, 320, 5, 5);
  ellipse(370, 270, 5, 5);


  
  
}