function setup() {
  createCanvas(400, 400);
  angleMode(RADIANS);
  var finalscore = 5;
  print(finalscore);
}

function draw() {
	background(0);
	for (var x = 35; x < width + 70; x += 70) {
		pacman(x, 110);	}
}
function pacman(x, y) {
	push();
	translate(x, y);
    rotate(PI / 3.0);
	noStroke();
    fill(247, 250, 67);
  	arc(0, 25, 35, 35, 0, PI+HALF_PI);
    fill(0);
    ellipse(-10, 20, 5, 5);
    fill(255);
	ellipse(15, 10, 5, 5);
    ellipse(20, 0, 5, 5);
    scale(1.5);
    ellipse(15, -8, 5, 5);
	pop();
}